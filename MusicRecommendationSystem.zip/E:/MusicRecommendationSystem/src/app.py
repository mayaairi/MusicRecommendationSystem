from flask import Flask, render_template, request, jsonify
from recommendation import MusicRecommender
import os

app = Flask(__name__)

@app.route("/", methods=["GET"])
def index():
    return render_template("index.html")

@app.route("/recommend", methods=["POST"])
def recommend():
    user_id = int(request.form["user_id"])

    # 初始化推荐器
    recommender = MusicRecommender()

    try:
        recommendations = recommender.get_recommendations(user_id)
        return jsonify({"success": True, "recommendations": recommendations})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})
    finally:
        recommender.close()

if __name__ == "__main__":
    # 确保数据集存在
    if not os.path.exists("data/user_artist_data.txt"):
        print("生成数据集...")
        os.system("python generate_data.py")

    app.run(debug=True)