import random

def generate_user_artist_data(file_path, num_users=100, num_artists=200, max_play_count=100):
    with open(file_path, "w") as f:
        for user_id in range(1, num_users + 1):
            # 每个用户随机播放10-50个艺术家（范围1-200）
            num_played_artists = random.randint(10, 50)
            played_artists = random.sample(range(1, num_artists + 1), num_played_artists)
            for artist_id in played_artists:
                play_count = random.randint(1, max_play_count)
                f.write(f"{user_id} {artist_id} {play_count}\n")

if __name__ == "__main__":
    generate_user_artist_data("data/user_artist_data.txt")
    print("数据集生成完成！艺术家ID范围：1-200")