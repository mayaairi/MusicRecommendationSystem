from pyspark.sql import SparkSession
from pyspark.ml.recommendation import ALS
from pyspark.sql.functions import col

class MusicRecommender:
    def __init__(self):
        self.spark = SparkSession.builder \
            .appName("MusicRecommendationSystem") \
            .getOrCreate()
        
        # 加载数据（确保路径正确）
        self.artist_data = self.spark.read.text("data/artist_data.txt") \
            .selectExpr(
                "cast(split(value, ' ')[0] as int) as artist_id",
                "regexp_replace(substring(value, instr(value, ' ')+1), '\t', ' ') as artist_name"
            ).cache()  # 添加缓存提高性能
        
        self.user_artist_data = self.spark.read.text("data/user_artist_data.txt") \
            .selectExpr(
                "cast(split(value, ' ')[0] as int) as user_id",
                "cast(split(value, ' ')[1] as int) as artist_id",
                "cast(split(value, ' ')[2] as int) as play_count"
            ).cache()
        
        # 训练ALS模型
        self.als = ALS(
            maxIter=10,
            regParam=0.01,
            userCol="user_id",
            itemCol="artist_id",
            ratingCol="play_count",
            coldStartStrategy="drop",
            implicitPrefs=True  # 使用隐式反馈数据
        )
        self.model = self.als.fit(self.user_artist_data)
    
    def get_recommendations(self, user_id, num_recommendations=10):
        try:
            # 生成推荐
            user_df = self.spark.createDataFrame([(user_id,)], ["user_id"])
            recommendations = self.model.recommendForUserSubset(user_df, num_recommendations)
            
            # 提取推荐结果
            recs = recommendations.collect()[0]["recommendations"]
            
            # 获取艺术家ID列表
            artist_ids = [r["artist_id"] for r in recs]
            
            # 查询艺术家名称（使用join提高效率）
            artist_info = self.artist_data.filter(col("artist_id").isin(artist_ids)) \
                .select("artist_id", "artist_name").collect()
            
            # 构建名称映射字典
            name_map = {row["artist_id"]: row["artist_name"] for row in artist_info}
            
            # 构建最终结果（修正round语法错误）
            result = [{
                "artist_id": r["artist_id"],
                "artist_name": name_map.get(r["artist_id"], "Unknown Artist"),
                "rating": round(float(r["rating"]), 2)  # 修正这里，确保括号闭合
            } for r in recs]
            
            return result
            
        except Exception as e:
            print(f"Error generating recommendations: {str(e)}")
            return []
    
    def close(self):
        self.spark.stop()
